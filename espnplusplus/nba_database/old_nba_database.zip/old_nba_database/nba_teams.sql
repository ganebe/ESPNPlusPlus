-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: nba
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `teams`
--

DROP TABLE IF EXISTS `teams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `teams` (
  `id` int NOT NULL,
  `abbreviation` varchar(3) NOT NULL,
  `nickname` varchar(13) NOT NULL,
  `city` varchar(13) NOT NULL,
  `state` varchar(20) NOT NULL,
  `full_name` varchar(22) NOT NULL,
  `year_founded` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teams`
--

LOCK TABLES `teams` WRITE;
/*!40000 ALTER TABLE `teams` DISABLE KEYS */;
INSERT INTO `teams` VALUES (1610612737,'ATL','Hawks','Atlanta','Atlanta','Atlanta Hawks',1949),(1610612738,'BOS','Celtics','Boston','Massachusetts','Boston Celtics',1946),(1610612739,'CLE','Cavaliers','Cleveland','Ohio','Cleveland Cavaliers',1970),(1610612740,'NOP','Pelicans','New Orleans','Louisiana','New Orleans Pelicans',2002),(1610612741,'CHI','Bulls','Chicago','Illinois','Chicago Bulls',1966),(1610612742,'DAL','Mavericks','Dallas','Texas','Dallas Mavericks',1980),(1610612743,'DEN','Nuggets','Denver','Colorado','Denver Nuggets',1976),(1610612744,'GSW','Warriors','Golden State','California','Golden State Warriors',1946),(1610612745,'HOU','Rockets','Houston','Texas','Houston Rockets',1967),(1610612746,'LAC','Clippers','Los Angeles','California','Los Angeles Clippers',1970),(1610612747,'LAL','Lakers','Los Angeles','California','Los Angeles Lakers',1948),(1610612748,'MIA','Heat','Miami','Florida','Miami Heat',1988),(1610612749,'MIL','Bucks','Milwaukee','Wisconsin','Milwaukee Bucks',1968),(1610612750,'MIN','Timberwolves','Minnesota','Minnesota','Minnesota Timberwolves',1989),(1610612751,'BKN','Nets','Brooklyn','New York','Brooklyn Nets',1976),(1610612752,'NYK','Knicks','New York','New York','New York Knicks',1946),(1610612753,'ORL','Magic','Orlando','Florida','Orlando Magic',1989),(1610612754,'IND','Pacers','Indiana','Indiana','Indiana Pacers',1976),(1610612755,'PHI','76ers','Philadelphia','Pennsylvania','Philadelphia 76ers',1949),(1610612756,'PHX','Suns','Phoenix','Arizona','Phoenix Suns',1968),(1610612757,'POR','Trail Blazers','Portland','Oregon','Portland Trail Blazers',1970),(1610612758,'SAC','Kings','Sacramento','California','Sacramento Kings',1948),(1610612759,'SAS','Spurs','San Antonio','Texas','San Antonio Spurs',1976),(1610612760,'OKC','Thunder','Oklahoma City','Oklahoma','Oklahoma City Thunder',1967),(1610612761,'TOR','Raptors','Toronto','Ontario','Toronto Raptors',1995),(1610612762,'UTA','Jazz','Utah','Utah','Utah Jazz',1974),(1610612763,'MEM','Grizzlies','Memphis','Tennessee','Memphis Grizzlies',1995),(1610612764,'WAS','Wizards','Washington','District of Columbia','Washington Wizards',1961),(1610612765,'DET','Pistons','Detroit','Michigan','Detroit Pistons',1948),(1610612766,'CHA','Hornets','Charlotte','North Carolina','Charlotte Hornets',1988);
/*!40000 ALTER TABLE `teams` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-03-08  9:52:49
